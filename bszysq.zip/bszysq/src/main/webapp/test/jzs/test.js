var c = {
	"avatar" : "http://image.aixuexi.com/avatar/14/1f1875420747fe83b764566163ab3114.jpg",
	"id" : 16713,
	"identity" : "teacher",
	"insCode" : "ceshi",
	"insId" : 25,
	"insName" : "阿凡达",
	"insType" : 1,
	"password" : "e10adc3949ba59abbe56e057f20f883e",
	"sex" : 0,
	"status" : 1,
	"teacherCode" : "ceshiT0016713",
	"teacherName" : "阿斯蒂芬",
	"telPhone" : "15201569320",
	
	"userId" : 2562,
	"isInBaiMingDan" : 1,
	"isxinshou" : 1,
	"roles" : [ {
		"roleName" : "teacher",
		"id" : 11
	}, {
		"roleName" : "assistant",
		"id" : 22
	} ]
};