package com.bszy.admin.mapper;

import com.bszy.admin.pojo.Smscode;
import com.mao.ssm.BaseMapper;

/**
 * 
 * @author Mao 2016年10月26日 上午1:23:12
 */
public interface SmscodeMapper extends BaseMapper<Smscode> {
	
}