package com.bszy.admin.controller;

import org.springframework.stereotype.Controller;

@Controller
public class MiscController {
	
	// TODO 页面
	
//	@RequestMapping(value = "/page/404", method = RequestMethod.GET)
//	public String page_404() {
//		return "exception/page/404";
//	}
	
	// TODO ajax
	
//	@ResponseBody
//	@RequestMapping(value = "/ajax/404", method = RequestMethod.GET)
//	public AjaxResult ajax_404(){
//		AjaxResult ar = new AjaxResult();
//		ar.setCode("404");
//		return ar;
//	}
	
}
