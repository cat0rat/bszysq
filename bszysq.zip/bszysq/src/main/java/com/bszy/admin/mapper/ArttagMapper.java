package com.bszy.admin.mapper;

import com.bszy.admin.pojo.Arttag;
import com.mao.ssm.BaseMapper;

/**
 * 
 * @author Mao 2016年10月26日 上午1:23:12
 */
public interface ArttagMapper extends BaseMapper<Arttag> {
	
}