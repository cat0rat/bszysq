package com.bszy.app.mapper;

import com.bszy.app.pojo.AppSysmsg;
import com.mao.ssm.BaseMapper;

/**
 * 
 * @author jzs 2016年11月27日 下午4:47:49
 */
public interface AppSysmsgMapper extends BaseMapper<AppSysmsg> {
}